/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salary_claculation;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author sairam
 */
public class Salary_ClaculationTest {
    
    public Salary_ClaculationTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of CalculateNet method, of class Salary_Calculation.
     */
    @Test
    public void testCalculateNet() {
        System.out.println("CalculateNet");
        int hours = 1;
        double pay_rate = 0.1;
        float tax = 1F;
        
        Salary_Claculation instance = new Salary_Claculation();
        
        double expResult = 1;
        double result = instance.CalculateNet(hours, pay_rate, tax);
        assertEquals(expResult, result);
        
    }
    
}
